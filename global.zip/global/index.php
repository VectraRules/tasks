<?PHP include_once "appStart.php";  ?>
<!DOCTYPE html>
<html lang="en">

<link rel="stylesheet" type="text/css" href="app.css">
<script src="jquery-3.7.1.min.js"></script>
<script src="sha512.js"></script>

<body style="background:black;font-family: Segoe UI">

	<form enctype="multipart/form-data">
		<input style="display:none" onchange="uploadFile('userImgUpload');" id="userImgUpload" type="file" class="form-control" />
	</form>

<div id=mainDisp style="position:fixed; top: 0px ; left; 0px; width:100%; height:100%;display:none;color:white">
	<br>
	<div id=appName style="position:fixed;top:5px;left:15px; width:500px;height:80px;display:none"><b style=font-size:250%>My Tasks</b><br>&nbsp;&nbsp;&nbsp;<span>version 0.1a</span></div>

	

	<div id=membersArea style="position:fixed;top:0px;left:0px; width:100%;height:100%">
		<div style="position:fixed;top:0px;left:0px;width:100%;height:80px;box-shadow:grey 0px 0px 10px;background-color:rgb(20,20,20)">
			<div><b style=font-size:250%>&nbsp;My Tasks</b><br>&nbsp;&nbsp;&nbsp;<span>version 0.1a</span>&nbsp;&nbsp;&nbsp;<b onclick="logOut()" style=font-size:120%;float:right;margin-right:10px;margin-top:-15px;cursor:pointer>LOG OUT </b></div>
		</div>
		<div style="margin-top:95px;padding:5px">
			<table style=color:white>
				<tr>
					<td style="width:310px">
						<div style="padding:10px;box-shadow:grey 0px 0px 5px;width:300px;border-radius:15px;background-color:rgb(20,20,20);overflow-y:auto" id=menuPane>
							<br>
							<div id=memberImageDisplay onclick="$('#userImgUpload').click()" style="width:200px;height:200px;box-shadow:grey 0px 0px 10px;margin-left:50px;border-radius:200px;background-position:center;background-size:cover;background-repeat:no_repeat">&nbsp;</div>
							<br><div style="font-size:150%;text-align:center" id=memberNameDisplay></div>
							<br><div style="font-size:100%;text-align:center" id=memberEmailDisplay></div>
							<hr>
							<br><div style="font-size:150%;text-align:center;padding:10px;border:1px solid grey; border-radius:15px;cursor:pointer" onclick="editMemberDetails()" id=menuEditProfile>My Profile</div>
							<br><div style="font-size:150%;text-align:center;padding:10px;border:1px solid grey; border-radius:15px;cursor:pointer" onclick="editTasks()" id=menuOpenTasks>Task List</div>
							<br>
							<br><div style="font-size:150%;text-align:center;padding:10px;border:1px solid grey; border-radius:15px;cursor:pointer;display:none" id=menuAdminViewUsers>View Users</div>
							
						</div>
					</td>
					<td style=width:10px>&nbsp;</td>
					<td id=mainAreaCol>
						<div style="padding:10px; box-shadow:grey 0px 0px 5px;width:300px;border-radius:15px 0px 0px 15px;background-color:rgb(20,20,20);overflow-y:auto" id=mainAreaSpace>
							<div class=memArea style=text-align:center;display:none id=profileNotice >There are still some items missing from your profile. Please complete your profile below<br><br></div>
							<div class=memArea style=text-align:center;display:none id=viewUsers ></div>
							<div class=memArea style=text-align:center;text-align:center><br><br>Welcome</div>
							<div class=memArea style=text-align:center;display:none id=editMemberDetails>
								<b>Profile Details</b><br>
								<span style=font-size:80%>You can edit your details here, note changes are logged immediately</span><br><br>
								<div style=display:inline-block;width:30%>First Name</div> <input class="loginInput no-outline" onchange="upDetails('userName','memFirstNameInput',0)" id=memFirstNameInput type=text style="height:50px" placeholder=" first name" />
								<br><div style=display:inline-block;width:30%>Last Name</div> <input class="loginInput no-outline" onchange="upDetails('userSurname','memLastNameInput',0)" id=memLastNameInput  type=text style="height:50px" placeholder=" last name"/>

								<br><div style=display:inline-block;width:30%>Mobile Number</div> <input class="loginInput no-outline" onchange="upDetails('userMobileNumber','memMobileInput',1)" id=memMobileInput  type=text style="height:50px" onkeyup="checkCell('memMobileInput')" placeholder=" Mobile Number"/>
								<br><div style=display:inline-block;width:30%>Email Address</div> <input class="loginInput no-outline" onchange="upDetails('userEmail','memEmailInput',1)" id=memEmailInput  type=text style="height:50px" onkeyup="checkAlphaNumericMail('memEmailInput')" placeholder=" Email"/>

								<br><div style=display:inline-block;width:30%>Profile Image</div> <input disabled=disabled class="loginInput no-outline" type=text style="height:50px" value=" Click on your profile image to change it"/>
								<br><div style=display:inline-block;width:30%>Date Registered</div> <input disabled=disabled class="loginInput no-outline" id=memDateRegInput  type=text style="height:50px"/>
								
							</div>



							<div class=memArea style=text-align:center;display:none id=editTaskList>
								<b>Tasks</b><br>
								<div id=tasksView></div>
								<div id=newTasksView style=display:none>
									<span class=taskMsg id=newTaskMsg style=display:none;font-size:80%>Input detail of your task below and hit submit when done</span>
									<span class=taskMsg id=editTaskMsg style=display:none;font-size:80%>Freely edit and hit update when done</span>
									<br><br>
									<input style=text-align:left class="loginInput no-outline" id=task-title type=text placeholder="Give your task a title" />
									<textarea style=text-align:left;height:150px;resize:none class="loginInput no-outline" id=task-description type=text placeholder="more detailed description of your task" ></textarea>
									<br>
									<input class="loginInput no-outline" id=task-dueDate type=date />

									<div id=addTaskBtns style=display:none>
										<br><button id=newTaskSubmitBtn onclick="submitTask()">Submit</button>&nbsp;&nbsp;&nbsp;
										<button id=newTaskCancel onclick="cancelTask()">Cancel</button>
									</div>
									
									<div id=editTaskBtns style=display:none>
										<br><button id=editTaskUpdateBtn onclick="updateTask()">Update</button>&nbsp;&nbsp;&nbsp;
										<button id=newTaskCancel onclick="cancelTask()">Cancel</button>
									</div>
								
								</div>
								
							</div>

						</div>
					</td>
				</tr>
			</table>
		</div>
		
	</div>

	<div id=loginBox style="display:none">
	<b>LOGIN</b>
	<hr>
		<div style=text-align:center>
			<div id=loginMsg style=text-align:left;font-size:80%>Enter your user name or email address to start</div>
			<div id=twoFactorSpace>
			<input class="loginInput no-outline" id=login-username onkeyup=checkAlphaNumericMail('login-username') type=text style="" placeholder=" user name or email address" autocomplete="off" readonly onfocus="this.removeAttribute('readonly');" />
			<input class="loginInput no-outline" id=login-password type=password placeholder=" password" />
			<br><br><hr>
			<div id=btn-submitLogin disabled="disabled" class=pageBtn style="margin:0 auto 0 auto;width:150px;float:right">continue</div>
			</div> 
			<br><br>
			<div id=errDisp style="position:relative;text-align:left;font-size:80%;color:red;font-style:bold;bottom:0px"></div>
			<br>
			<div style=text-align:center;font-size:80%>Not a member yet <span onclick="$('#loginBox').fadeOut(0);$('#regBox').fadeIn(500)" style="padding:3px;border:1px solid grey;border-radius:4px;cursor:pointer">Register Here<br></div>
			</div>
			
	</div>

	<div id=regBox style="display:none">
	<b>REGISTER</b>
	<hr>
		<div style=text-align:center>
			<div id=loginMsg style=text-align:left;font-size:80%>Enter your email address and create a password to start<br></div>
			<div>
				<input class="loginInput no-outline" onkeyup=checkAlphaNumericMail('reg-username') id=reg-username type=text style="" placeholder=" email address" autocomplete="off" readonly onfocus="this.removeAttribute('readonly');" />
				<input class="loginInput no-outline" id=reg-pass1 type=password placeholder=" password" />
				<input class="loginInput no-outline" id=reg-pass2 type=password placeholder=" password" />
				<br><br><hr>
				<div id=btn-submitReg disabled="disabled" class=pageBtn style="margin:0 auto 0 auto;width:150px;float:right">Submit</div>
			</div> 
			<br><br>
			<div id=errDispReg style="position:relative;text-align:left;font-size:80%;color:red;font-style:bold;bottom:0px"></div>
		</div>
			
	</div>

</div>


<script>



var CNJS = 'https://davec-it.co.za/global'; // Server location and accompanying cookie to ensure all scripts point to the correct source

window.addEventListener("resize", positionElements); // Trigger to resize and scale in relation to window size and display orientation
function positionElements() {
	var mdHeight = $("#mainDisp").height();
	var mdWidth = $("#mainDisp").width();
	
			$("#loginBox").css("left", ((mdWidth - 450) / 2) + "px");
			$(".loginInput").css("width", "450px");

			$("#regBox").css("left", ((mdWidth - 450) / 2) + "px");
			$(".loginInput").css("width", "450px");
			
			$("#mainDisplayArea").css("width", ((mdWidth - 205)) + "px");
			$("#mainDisplayArea").css("height", mdHeight + "px");
			
			$("#menuPane").css("height", (mdHeight - 145) + "px");
			$("#mainAreaSpace").css("height", (mdHeight - 145) + "px");
			$("#mainAreaSpace").css("width", (mdWidth - 380) + "px");
			
}

// inline input limiters, attache to element via onkeyup with the element name as parameter, will not allow certain characters to be typed - double data validation
function checkAlphaNumeric(elem) {
    var x = document.getElementById(elem);
    x.value = x.value.replace(/[`~!#$%^&*()_|+\=?;:",.<>\{\}\[\]\\\/]/gi, '');
}
function checkAlphaNumericAddress(elem) {
    var x = document.getElementById(elem);
    x.value = x.value.replace(/[`~!#$%^&*()_|+\=?;:".<>\{\}\[\]\\\/]/gi, '');
}
function checkAlphaNumericSpes(elem) {
    var x = document.getElementById(elem);
    x.value = x.value.replace(/[`~!#$%^&*()_|+\=?;:",.<>\{\}\[\]\\]/gi, '');
}
function checkAlphaNumericMail(elem) {
    var x = document.getElementById(elem);
    x.value = x.value.replace(/[`~!#$%^&*()|+\=?;:",'<>\{\}\[\]\\\/]/gi, '');
}
function checkCell(elem) {
    var x = document.getElementById(elem);
    x.value = x.value.replace(/[abcdefghijklmnopqrstuvwxyz` ~!@#$%^&*()_|\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
}	

function editMemberDetails() { // switch to display profile edit page
	$(".memArea").fadeOut(0);
	$("#editMemberDetails").fadeIn(500);
}

// element event management
$("#login-password").keypress(function(e) { if (e.which == 13) { $("#btn-submitLogin").click()}});
$("#reg-pass2").keypress(function(e) { if (e.which == 13) { $("#btn-submitReg").click()}});
$("#btn-submitReg").click(function(e) {submitReg()});
$("#menuAdminViewUsers").click(function(e) {showUsers()});


// Process Login - Check Pass
$("#btn-submitLogin").click(function(e) {
	if ($("#login-password").val().length > 0) {
		
		var pswSend = CryptoJS.SHA512($("#login-password").val()).toString();
		
				$.post(CNJS + "/appAPI.php",
				{
					func: "chkPass",
					data: bin2hex(pswSend) + "[*-*]" + bin2hex($("#login-username").val())
				},
				function (data, status) {

					if (data.split("[RES]")[1] == 1) {
						$("#loginBox").fadeOut(0);
						$("#regBox").fadeOut(0);
						$("#appName").fadeOut(0);
						$("#membersArea").fadeIn(500);
						
						getUserData();

						pmode = "SHOW_MEM_AREA";
						
						window.location.reload();
						

					} else {
						$("#errDisp").html("!! The password is incorrect");	
					}
				});
	}	
});

function bin2hex(binVal) { // converts text field to hex notation, is stored in db as hex code

  var i = 0, l = binVal.length, chr, hex = ''

  for (i; i < l; ++i){
    chr = binVal.charCodeAt(i).toString(16)
    hex += chr.length < 2 ? '0' + chr : chr
  }

  return hex
}

function logOut() {

	$.post(CNJS + "/appAPI.php",
	{
		func: "logoutnow"
	},
	function (data, status) {
		window.location.reload();
	});

	
}

function pageSize(newSize) { // Tasks view display size change
	$.post(CNJS + "/appAPI.php",
	{
		func: "updatePageSizeCookie",
		newVal: newSize
	},
	function (data, status) {
		editTasks();
	});
	
}

function jumpList(newStartPoint) { // Select page to view on tasks display
	$.post(CNJS + "/appAPI.php",
	{
		func: "jumpToPage",
		newVal: newStartPoint
	},
	function (data, status) {
		editTasks();
	});
}

function addTask() {	// Sets up display for entry of new task
	$("#tasksView").fadeOut(0);
	$("#newTasksView").fadeIn(500);
	
$("#taskMsg").fadeOut(0);
$("#newTaskMsg").fadeIn(0);	

$("#addTaskBtns").fadeIn(0);
$("#editTaskBtns").fadeOut(0);
	
}

function submitTask() {	// Validates and send data for create function for task in DB
	
	if ($("#task-title").val() == "" || $("#task-dueDate").val() == "") {
		alert("Cannot submit your task\n\nAs a minimum you need to specify a Title and Due Date");
	} else {

		$.post(CNJS + "/appAPI.php",
		{
			func: "addTask",
			title: bin2hex($("#task-title").val()),
			desc: bin2hex($("#task-description").val()),
			duedate: $("#task-dueDate").val()
		},
		function (data, status) {
			cancelTask();
			editTasks();
		});
	}
}

function submitUpdate() { // Updates task info

	if ($("#task-title").val() == "" || $("#task-dueDate").val() == "") {
		alert("Cannot submit your task changes\n\nAs a minimum you need to have a value specified as Title and a selected Due Date");
	} else {

		$.post(CNJS + "/appAPI.php",
		{
			func: "editTask",
			title: bin2hex($("#task-title").val()),
			desc: bin2hex($("#task-description").val()),
			duedate: $("#task-dueDate").val()
		},
		function (data, status) {
			cancelTask();
			editTasks();
		});
	}	
}

var currentTaskOnEdit = 0; 

function updateTask() {	// update task details

	$.post(CNJS + "/appAPI.php",
	{
		func: "updateTaskDetails",
		title: bin2hex($("#task-title").val()),
		desc: bin2hex($("#task-description").val()),
		duedate: $("#task-dueDate").val(),
		taskID: currentTaskOnEdit
	},
	function (data, status) {
		cancelTask();
		editTasks();
		currentTaskOnEdit = 0;
	});

	
}

function delTask(taskID) { // Remove entry from db
	var chk = confirm("You are about to delete this task (Ref: " + taskID + ")\n\n Are you sure?");
	
	if (chk) {
		$.post(CNJS + "/appAPI.php",
		{
			func: "delTask",
			taskID: taskID
		},
		function (data, status) {
			
		cancelTask();
		editTasks();		

		});

	} 
}

function updateStatus(taskID) { // change status of Task

		$.post(CNJS + "/appAPI.php",
		{
			func: "updateTaskStatus",
			taskID: taskID,
			newVal: $("#task_" + taskID + "").val()
		},
		function (data, status) {

		});

	
}

function editTask(taskID) { // Edit task detail

	$.post(CNJS + "/appAPI.php",
	{
		func: "taskEditCurrent",
		taskID: taskID
	},
	function (data, status) {
		
	currentTaskOnEdit = taskID;	

	$("#tasksView").fadeOut(0);
	$("#newTasksView").fadeIn(500);

	$("#taskMsg").fadeOut(0);
	$("#editTaskMsg").fadeIn(0);	
		
	$("#addTaskBtns").fadeOut(0);
	$("#editTaskBtns").fadeIn(0);
	
	$("#task-title").val(data.split("[TITLE]")[1]);
	$("#task-description").val(data.split("[DESC]")[1]);
	$("#task-dueDate").val(data.split("[DD]")[1]);
	

	});


}

function cancelTask() { // Cancel / Delete Task from your personal dashboard
	$("#task-title").val("");
	$("#task-description").val("");
	$("#task-dueDate").val("");

	$("#taskMsg").fadeOut(0);
	
	$("#editTaskView").fadeOut(0);
	$("#newTasksView").fadeOut(0);
	
	$("#tasksView").fadeIn(500);
}

function showUsers() { // Calls for generate and displays a list of app users
	$.post(CNJS + "/appAPI.php",
	{
		func: "showUsers"
	},
	function (data, status) {
		$(".memArea").fadeOut(0);
		$("#viewUsers").fadeIn(500);
		$("#viewUsers").html(data.split("[OUT]")[1]);
		
	});
	
}

function editTasks() { // Sets up display for Tasks edit
	$.post(CNJS + "/appAPI.php",
	{
		func: "getUserTasks"
	},
	function (data, status) {

			$(".memArea").fadeOut(0);
			$("#editTaskList").fadeIn(500);
			$("#tasksView").html(data.split("[OUT]")[1]);
			
			
	});
	
}

function getUserData() {  // Retrieve basic detail of all registered App users
	$.post(CNJS + "/appAPI.php",
	{
		func: "getUserDetail"
	},
	function (data, status) {
			
			$("#memberNameDisplay").html(data.split("[FN]")[1] + " " + data.split("[LN]")[1]);
			$("#memberEmailDisplay").html(data.split("[EM]")[1]);
			$("#memberImageDisplay").css("background-image","url('img/" + data.split("[IMG]")[1] + "')");

			if (data.split("[RL]")[1] == 100) {
				$("#menuAdminViewUsers").fadeIn(500);
			}
			// Update screen elements
			$("#memFirstNameInput").val(data.split("[FN]")[1]);
			$("#memLastNameInput").val(data.split("[LN]")[1]);
			$("#memMobileInput").val(data.split("[MN]")[1]);
			$("#memEmailInput").val(data.split("[EM]")[1]);
			$("#memImageInput").val(""); // data.split("[IMG]")[1]
			$("#memDateRegInput").val(data.split("[RW]")[1]);
			$("#memRoleInput").val(data.split("[RL]")[1]);
				
	});
}


function upDetails(field1,val1,nobin) { // Update member profile information on the fly
	
	if (nobin == 1) {
		data_data = $("#" + val1).val();
	} else {
		data_data = bin2hex($("#" + val1).val());
	}
	
	$.post(CNJS + "/appAPI.php",
	{
		func: "updateDetails",
		field: field1,
		data: data_data,
		uid: "<?PHP echo $uid; ?>",
		nb: nobin
	},
	function (data2, status) {
		$("#memberNameDisplay").html(data2.split("[FN]")[1]);
		$("#memberEmailDisplay").html(data2.split("[EM]")[1]);
	});
}

function isEmail(email) { // Validate Email address
  var regex = /^([a-zA-Z0-9_.+-])+\@(([a-zA-Z0-9-])+\.)+([a-zA-Z0-9]{2,4})+$/;
  return regex.test(email);
}

function submitReg() { // Submit Registrtion data for new user

	// Validation indicators
	var mail_good = false;
	var pass_good = false;
	
	if ($("#reg-username").val() > "") {
		if (isEmail($("#reg-username").val()) == true) {
			mail_good = true;
		} else {
			$("#errDispReg").html("!! Email address is not valid");
		}
	} else {
		$("#errDispReg").html("!! Email address empty");
	}
	
	if ($("#reg-pass1").val() > "" && $("#reg-pass2").val() > "" ) {
		if ($("#reg-pass1").val() == $("#reg-pass2").val()) {
			pass_good = true;
		} else {
			$("#errDispReg").html("!! Passwords must be the same");
		}
	} else {
		$("#errDispReg").html("!! Complete both password boxes");
	}
	
	if (mail_good && pass_good) {
		
		var pswSend2 = CryptoJS.SHA512($("#reg-pass1").val()).toString();

		$.post(CNJS + "/appAPI.php",
		{
			func: "regnew",
			username: $("#reg-username").val(),
			userpass: bin2hex(pswSend2)
		},
		function (data, status) {
			
				if (data.split("[RES]")[1] == 1) {
						$.post(CNJS + "/appAPI.php",
						{
							func: "chkPass",
							data: bin2hex(pswSend2) + "[*-*]" + bin2hex($("#reg-username").val())
						},
						function (data2, status) {
								//alert(data);
							if (data2.split("[RES]")[1] == 1) {
								$("#loginBox").fadeOut(0);
								$("#regBox").fadeOut(0);
								$("#appName").fadeOut(0);
								$("#membersArea").fadeIn(500);
								
								getUserData();

/*                                	$.post(CNJS + "/appAPI.php",
                                	{
                                		func: "MailConfirmation",
                                		uuid: data2.split("[uuid]")[1],
                                		nb: nobin
                                	},
                                	function (data3, status) {
                                        console.log(data3);                                
                                	});*/



								pmode = "SHOW_MEM_AREA";
								
								window.location.reload();
								

							} else {
								$("#errDisp").html("!! The password is incorrect");	
							}
						});
					
				}
				if (data.split("[RES]")[1] == 0) {
					alert(data.split("[MSG]")[1]);
				}
			

		});
			
	}

}


$( document ).ready(function () {	// init page load functions
	$("#login-username").val("");
	$("#login-password").val("");
	var pmode = "<?PHP echo $PAGE_MODE ?>";

	
	$("#mainDisp").fadeIn(0); // displays the main UI screen
		switch (pmode) { // Define screen behaviours dependent on logged in person and reverts to login if no active user detected
			case "SHOW_LOGIN":
				$("#loginBox").fadeIn(500);
				$("#appName").fadeIn(0);
				$("#regBox").fadeOut(0);
				$("#membersArea").fadeOut(0);
				$("#login-username").focus();
				break;
			case "SHOW_MEM_AREA":
				$("#loginBox").fadeOut(0);
				$("#appName").fadeOut(0);
				$("#regBox").fadeOut(0);
				$("#membersArea").fadeIn(500);
				
				getUserData();	// Pulls logged in user detail
				editTasks();	// Displays taask screen 
								
				break;
			default:
				alert("Something went wrong :(");
		}
	positionElements();
	
	
});


function uploadFile(upGroup) {	// image upload process with reload

    var upTypeProcessDestination = "upImg.php";

    if ($("#" + upGroup).val() != "") {	
        var file_data = $('#' + upGroup).prop('files')[0];
        var form_data = new FormData();
        form_data.append('file', file_data);

        $.ajax({
            url: upTypeProcessDestination,
            dataType: 'text', 
            cache: false,
            contentType: false,
            processData: false,
            data: form_data,
            type: 'post',
            success: function (data) {
				//alert(data);
                if (data.split("[RES]")[1] == "1") {
					$("#memberImageDisplay").css("background-image","url('" + CNJS + "/img/" + data.split("[FN]")[1] + "')");
                }
                if (data.split("[RES]")[1] == "0") {
                        alert("Something went wrong. We could not upload the file\n\nCheck that the file is smaller than 10MB<br>Only JPG and PNG file formats are permitted");
                }

                // clear file field
                $("#" + upGroup).val("");
            }
        });
    }
    else {

    }

}


</script>
	
</body>
</html> 
