<?php
//Access-Control-Allow-Origin header with wildcard.
header('Access-Control-Allow-Origin: *');
date_default_timezone_set('Africa/Cairo');

$cur_date = date('Y/m/d H:i:s');
$usr = $_COOKIE["MPUID"];

// !!!!!!!!!!!!!!!!!!!! //
// !!!!!!!!!!!!!!!!!!!! //
// !!!!!!!!!!!!!!!!!!!! //
// !!!!!!!!!!!!!!!!!!!! //

include('db.php');

$allowedExts = array("JPEG", "jpeg", "jpg", "JPG", "png", "PNG", "gif", "GIF");

$go_ahead = 0;

if ( empty($_FILES)) { $go_ahead = 0; exit('[RES]0[RES]'); };


	$temp = explode(".", strtolower($_FILES["file"]["name"]));
	$path = "img/users/";
	
	$extension = end($temp);

	if (($_FILES["file"]["type"] == "image/jpeg") || ($_FILES["file"]["type"] == "image/png")) {
		$go_ahead = 1;
	} else {
		$go_ahead = 0;
	}
		

	if (($_FILES["file"]["size"] < 10000000) && (in_array($extension, $allowedExts)) ) {
		$go_ahead = 1;
	} else {
		$go_ahead = 0;
	}


if ($go_ahead == 1)
{
  if ($_FILES["file"]["error"] > 0)
  {
	  echo "[E]" . $_FILES["file"]["error"] . "[E]";
  }
  else
  {
		$number_is_unique = 0;
		$file_number = '';
		$file_type = '.' . $extension;
		
		while ($number_is_unique == 0) {
			$fname = '' . strval(rand(1000,9999)) . '-' . strval(rand(100000,999999)) . '-' . strval(rand(10000,99999));
			$fname_test = $fname . '.' . $extension;
			$stmt = $con->prepare("SELECT COUNT(*) AS total FROM mytasksuserdetails WHERE userImage = ?"); 
			$stmt->bind_param('s', $fname_test );
			$stmt->execute();
			$stmt->bind_result($total);
			$stmt->fetch();
			$stmt->close();
			
			if ($total == 0) {$number_is_unique = 1; $file_number = $fname;};
		}

		$final_file_name = $file_number . $file_type;
		$orig_name = $_FILES["file"]["name"];
		$orig_size = $_FILES["file"]["size"];

			$im = "";
			
		$uploaded_file = $_FILES['file']['tmp_name']; 
        $exif = exif_read_data($uploaded_file);
        $deg = 0;
        
            if($exif && isset($exif['Orientation'])) {
                  $orientation = $exif['Orientation'];
                  if($orientation != 1){
                    switch ($orientation) {
                      case 3:
                        $deg = 180;
                        break;
                      case 6:
                        $deg = 270;
                        break;
                      case 8:
                        $deg = 90;
                        break;
                    }
                }
            } 	

        $upl_img_properties = getimagesize($uploaded_file);
		$new_file_name = $file_number;
        $folder_path = "img/";
        $img_ext = pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION);
        $image_type = $upl_img_properties[2];

        switch ($image_type) {
			//for PNG Image
            case IMAGETYPE_PNG:
                $image_type_id = imagecreatefrompng($uploaded_file); 
                $image_type_id = imagerotate($image_type_id, $deg, 0);        
                if ($deg == 270 || $deg == 90) { $target_layer = image_resize($image_type_id, $upl_img_properties[1], $upl_img_properties[0]);}
                                          else { $target_layer = image_resize($image_type_id, $upl_img_properties[0], $upl_img_properties[1]);};
                imagepng($target_layer, $folder_path. $new_file_name. ".". $img_ext);
                break;
            //for GIF Image
            case IMAGETYPE_GIF:
                $image_type_id = imagecreatefromgif($uploaded_file); 
                $image_type_id = imagerotate($image_type_id, $deg, 0);        
                if ($deg == 270 || $deg == 90) { $target_layer = image_resize($image_type_id, $upl_img_properties[1], $upl_img_properties[0]);}
                                          else { $target_layer = image_resize($image_type_id, $upl_img_properties[0], $upl_img_properties[1]);};
                imagegif($target_layer, $folder_path. $new_file_name.".". $img_ext);
                break;
            //for JPEG Image
            case IMAGETYPE_JPEG:
                $image_type_id = imagecreatefromjpeg($uploaded_file); 
                $image_type_id = imagerotate($image_type_id, $deg, 0);        
                if ($deg == 270 || $deg == 90) { $target_layer = image_resize($image_type_id, $upl_img_properties[1], $upl_img_properties[0]);}
                                          else { $target_layer = image_resize($image_type_id, $upl_img_properties[0], $upl_img_properties[1]);};
                imagejpeg($target_layer, $folder_path. $new_file_name.".". $img_ext);
                break;

            default:
                echo "Please select a 'PNG', 'GIF' or JPEG image";
                exit;
                break;

        }
        
        
		$full_name = $path . $final_file_name;
		
		$_uuid = "";
		$stmt = $con->prepare("SELECT UUID FROM mytasksusers WHERE UID = '$usr'");
		$stmt->execute();
		$stmt->bind_result($_uuid);
		$stmt->fetch();
		$stmt->close();	
			
		$stmt = $con->prepare("UPDATE mytasksuserdetails SET userImage = ? WHERE UUID = ?");
		$stmt->bind_param('si', $final_file_name, $_uuid);
		$stmt->execute();
		$stmt->close();
			
			
		
		echo "[RES]1[RES][FN]" . $final_file_name . "[FN]";

  }
} else {
	echo '[RES]0[RES]';
}

function image_resize($image_type_id, $img_width, $img_height) {
    
        $target_width = 800;
        $target_height = $img_height * (800 / $img_width);

    $target_layer= imagecreatetruecolor($target_width, $target_height);
    imagecopyresampled($target_layer, $image_type_id,0,0,0,0, $target_width, $target_height, $img_width, $img_height);
    return $target_layer;
}
	
mysqli_close($con);

?>
