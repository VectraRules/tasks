<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");
header("Access-Control-Allow-Methods: OPTIONS,POST,GET");

// !! Headers above for CORS management

//header("HTTP/1.1 200 OK");
//http_response_code(200);
date_default_timezone_set('Africa/Johannesburg');

if (isset($_POST["func"])) { $mode = $_POST["func"];} else {exit("[ERR]command-missing[ERR]");};

$cnjs = "https://davec-it.co.za/global";
$uid = $_COOKIE["MPUID"];
$auth1 = $_COOKIE["MPAUTHI"];
$auth2 = $_COOKIE["MPAUTHII"];

function hashPassword($password){
	$salt = "$2a$13" . "$" . "kd.Uki70lMoh1TSZIX3Z3j";
	$newPassword = $password;
	for($i=0; $i<25000; $i++) {
		$newPassword = hash('sha512',$salt.$newPassword.$salt);
	}
    return $newPassword;
}

if ($mode == "logoutnow") {
	setcookie("MPUID",0,
	[
	'expires' => -1,
	'path' => '/',
	'secure' => true,
	'httponly' => true,
	'samesite' => 'Strict'
	]);
	
	setcookie("MPAUTHI",0,
	[
	'expires' => -1,
	'path' => '/',
	'secure' => true,
	'httponly' => true,
	'samesite' => 'Strict'
	]);
	
	setcookie("MPAUTHII",0,
	[
	'expires' => -1,
	'path' => '/',
	'secure' => true,
	'httponly' => true,
	'samesite' => 'Strict'
	]);
}

if($mode == "taskEditCurrent") {
		include 'db.php';

		$stmt = $con->prepare("SELECT taskTitle, taskDescription, taskDueDate FROM taskDefinitions WHERE ID = '{$_POST["taskID"]}'");
		$stmt->execute();
		$stmt->bind_result($taskTitle, $taskDescription, $taskDueDate);
		$stmt->fetch();
		$stmt->close();

		echo "[TITLE]". hex2bin($taskTitle)."[TITLE]";
		echo "[DESC]". hex2bin($taskDescription)."[DESC]";
		echo "[DD]". date("Y-m-d", strtotime($taskDueDate)) ."[DD]";

		mysqli_close($con);
	
}

if ($mode == "jumpToPage") {
			setcookie("LS",$_POST["newVal"],
			[
				'expires' => 0,
				'path' => '/',
				'secure' => true,
				'httponly' => true,
				'samesite' => 'Strict'
			]);
}
	
if ($mode == "updatePageSizeCookie") {

			setcookie("PS",$_POST["newVal"],
			[
				'expires' => 0,
				'path' => '/',
				'secure' => true,
				'httponly' => true,
				'samesite' => 'Strict'
			]);

}	
	
if ($mode == "getUserTasks") {

	include 'db.php';

	$stmt = $con->prepare("SELECT UUID FROM mytasksusers WHERE UID = '{$_COOKIE["MPUID"]}'");
	$stmt->execute();
	$stmt->bind_result($__uuid);
	$stmt->fetch();
	$stmt->close();

	$totalTasks = 0;

	$stmt = $con->prepare("SELECT count(*) as totalTasks FROM taskDefinitions WHERE UUID = '{$__uuid}'");
	$stmt->execute();
	$stmt->bind_result($totalTasks);
	$stmt->fetch();
	$stmt->close();

	
	if (isset($_COOKIE["LS"])) {
		$list_start_pos = $_COOKIE["LS"];
	} else {
		$list_start_pos = 1;
	}

	if (isset($_COOKIE["PS"])) {
		$pageSize = $_COOKIE["PS"];
	} else {
		$pageSize = 5;
	}

	// Predefine select and update relevent current position for screen init
	$pageSizeSelCodeTemp = "<select style=width:50px onchange='pageSize($(this).val())' id=pageSizeSelect><option value=5>5</option><option value=10>10</option><option value=25>25</option><option value=50>50</option></select>";
	$pageSizeSelCode = str_ireplace("value={$pageSize}","value={$pageSize} selected", $pageSizeSelCodeTemp );
	unset($pageSizeSelCodeTemp);
		
	// Pageanation for tasks list	
	$list_end_pos = ($list_start_pos + $pageSize);
	
	if ($totalTasks > 0) {
		$pages = intval($totalTasks / $pageSize);
	} else {
		$pages = 1;
	}
	
	if ($pages == 0) { $pages = 1;}; 
	
	$pageSelCode = "<select style=width:50px onchange='jumpList($(this).val())' id=jumpSelect>";
		$pageCount = 1;
		$pageSelCode .= "<option value=1>1</option>";
		
		if ($totalTasks > $pageSize) {
			while ($pageCount <= $pages) {
				$pageCount++;
				$newPosition = (intval(($pageCount - 1) * $pageSize) + 1);
				if ($newPosition == $_COOKIE["LS"]) {
					$pageSelCode .= "<option value={$newPosition} selected>" . $pageCount . "</option>";
				} else {
					$pageSelCode .= "<option value={$newPosition}>" . $pageCount . "</option>";
				}
			}
		}
	$pageSelCode .= "</select>";
	
	if ($list_end_pos > $totalTasks) {
		$listEndDisplay = $totalTasks;
	} else {
		$listEndDisplay = ($list_end_pos - 1);
	}
	// Table headers for diaply
	$html_out = "<span style=font-size:80%>Below your ist of tasks in due date order, click on a task to edit its properties<br>Click the + Add button to add a new tasks </span><br><br>";
	$html_out .= "Displaying items {$list_start_pos} to {$listEndDisplay} of {$totalTasks} &nbsp;&nbsp;JUMP&nbsp;TO&nbsp;PAGE&nbsp;{$pageSelCode}&nbsp;&nbsp;PAGE&nbsp;SIZE&nbsp;{$pageSizeSelCode}";
	$html_out .= "<br><br><button id=addButton onclick='addTask()'>+ Add New Task</button><br><table style=width:100%;text-align:center>";
	$html_out .= "<tr><th style='background:lightgrey;color:black;box-shadow:white 0px 0px 5px'>Ref</th>";
	$html_out .= "<th style='background:lightgrey;color:black;box-shadow:white 0px 0px 5px'>Due&nbsp;Date</th>";
	$html_out .= "<th style='background:lightgrey;color:black;box-shadow:white 0px 0px 5px'>Status</th>";
	$html_out .= "<th style='background:lightgrey;color:black;box-shadow:white 0px 0px 5px'>Title</th>";
	$html_out .= "<th style='background:lightgrey;color:black;box-shadow:white 0px 0px 5px'>Description</th>";
	$html_out .= "<th style='background:lightgrey;color:black;box-shadow:white 0px 0px 5px'>Action</th></tr><tr><td colspan=6>&nbsp;</td></tr>";
	

	// Populate current Tasks info into table and for dump on browser screen

	if ($result = $con->query("SELECT * FROM taskDefinitions WHERE UUID = '{$__uuid}'  ORDER BY taskDueDate DESC LIMIT " . intval($list_start_pos - 1) . ", {$pageSize}"))
		{
			if ($result->num_rows > 0)
				{
					while($row = mysqli_fetch_array($result))
						{
							//ID	taskTitle	taskDescription	taskDueDate	taskAddDate	taskStatus
							
							$stat_temp = "<select id='task_".$row["ID"]."' style='background-color:black;color:lightgrey;border:1px solid grey;width:100%;font-size:100%' onchange='updateStatus({$row["ID"]})'>";
							if ($result2 = $con->query("SELECT * FROM taskStatus ORDER BY ID ASC"))
								{
									if ($result2->num_rows > 0)
										{
											while($row2 = mysqli_fetch_array($result2))
												{
													if ($row["taskStatus"] == $row2["ID"]) {
														$stat_temp .= "<option style='background-color:black;color:lightgrey;font-size:100%' value='{$row2["ID"]}' selected>{$row2["statusDesc"]}</option>";
													} else {
														$stat_temp .= "<option style='background-color:black;color:lightgrey;font-size:100%' value='{$row2["ID"]}'>{$row2["statusDesc"]}</option>";
													}
												}
										}
								}
							$stat_temp .= "</select";
							
							$html_out  .= "<tr><td>".$row["ID"]."</td><td>".date("Y-m-d", strtotime($row["taskDueDate"]))."</td><td>".$stat_temp."</td><td style=text-align:left>".hex2bin($row["taskTitle"])."</td><td style=text-align:left>".hex2bin($row["taskDescription"])."</td><td><span style='border:1px solid grey;cursor:pointer' onclick='editTask(".$row["ID"].")'>EDIT</span>&nbsp;&nbsp;<span style='border:1px solid grey;cursor:pointer' onclick='delTask(".$row["ID"].")'>DELETE</span></td>";
							$html_out  .= "<tr>";
						}
				}
		}

	$html_out .= "</table>";
	echo "[OUT]".$html_out."[OUT]";
	mysqli_close($con);
}


if ($mode == "delTask") {

	include 'db.php';

		$stmt = $con->prepare("DELETE FROM taskDefinitions WHERE ID = '{$_POST["taskID"]}'");
		$stmt->execute();
		$stmt->close();	

	mysqli_close($con);

	
}


if ($mode == "updateTaskStatus") {

	include 'db.php';

		$dt = date("Y-m-d H:i:s");

		$stmt = $con->prepare("UPDATE taskDefinitions SET taskStatus = '{$_POST["newVal"]}' WHERE ID  = '{$_POST["taskID"]}'");
		$stmt->execute();
		$stmt->close();	

	mysqli_close($con);

	
}

if ($mode == "addTask") {
	include 'db.php';

		$dt = date("Y-m-d H:i:s");
		
		$stmt = $con->prepare("SELECT UUID FROM mytasksusers WHERE UID = '{$_COOKIE["MPUID"]}'");
		$stmt->execute();
		$stmt->bind_result($__uuid);
		$stmt->fetch();
		$stmt->close();

		$stmt = $con->prepare("INSERT INTO taskDefinitions(taskTitle,taskDescription,taskDueDate,taskAddDate,taskStatus,UUID) VALUES('{$_POST["title"]}','{$_POST["desc"]}','{$_POST["duedate"]}','{$dt}',1,'{$__uuid}')");
		$stmt->execute();
		$stmt->close();	

	mysqli_close($con);
	
}	

if ($mode == "updateTaskDetails") {

	include 'db.php';

		$dt = date("Y-m-d H:i:s");

		$stmt = $con->prepare("UPDATE taskDefinitions SET taskTitle = '{$_POST["title"]}', taskDescription = '{$_POST["desc"]}', taskDueDate = '{$_POST["duedate"]}' WHERE ID  = '{$_POST["taskID"]}'");
		$stmt->execute();
		$stmt->close();	

	mysqli_close($con);

}


if ($mode == "editTask") {
	include 'db.php';

		$dt = date("Y-m-d H:i:s");

		$stmt = $con->prepare("INSERT INTO taskDefinitions(taskTitle,taskDescription,taskDueDate,taskAddDate,taskStatus) VALUES('{$_POST["title"]}','{$_POST["desc"]}','{$_POST["duedate"]}','{$dt}','New')");
		$stmt->execute();
		$stmt->close();	

	mysqli_close($con);
	
}	

	 
if ($mode == "updateDetails") {
	include 'db.php';

	if ($_POST["nb"] == 0) {
		$insVal = hex2bin($_POST["data"]);
		} else {
			$insVal = $_POST["data"];
			}
		
		$stmt = $con->prepare("SELECT UUID FROM mytasksusers WHERE UID = '{$_POST["uid"]}'");
		$stmt->execute();
		$stmt->bind_result($__uuid);
		$stmt->fetch();
		$stmt->close();
		
		$stmt = $con->prepare("UPDATE mytasksuserdetails SET ".$_POST["field"]." = '".$_POST["data"]."' WHERE UUID = '".$__uuid."'");
		$stmt->execute();
		$stmt->close();

		$stmt = $con->prepare("SELECT userName, userSurname, userEmail FROM mytasksuserdetails WHERE UUID = '".$__uuid."'");
		$stmt->execute();
		$stmt->bind_result($_un, $_ln, $_ue);
		$stmt->fetch();
		$stmt->close();
		
		$_fn = hex2bin($_un) . " " . hex2bin($_ln);
		echo "{$_POST["field"]}, {$insVal}, {$_POST["uid"]}[FN]" . $_fn . "[FN][EM]" . $_ue . "[EM]";

		
	mysqli_close($con);

}

if ($mode == "showUsers") {
	include "db.php";
	$html_out = "<br><br><table style=width:100%;min-width:100%;max-width:100%;color:black;background-color:lightgrey;text-align:center><tr><th style=text-align:left>IMAGE</th><th>Name</th><th>Email</th><th>Cell</th></tr>";
	
			if ($result = $con->query("SELECT userImage, userName, userSurname, userEmail, userMobileNumber FROM mytasksuserdetails"))
			{
				if ($result->num_rows > 0)
					{
					while($row = mysqli_fetch_array($result))
						{
							$html_out  .= "<tr><td><div style='width:50px;height:50px;border:1px solid black;background-image:url(img/{$row["userImage"]});background-size: contain; background-repeat:no-repeat;background-position:center'></div></td>";
							$html_out  .= "<td>" . hex2bin($row["userName"]) . " " . hex2bin($row["userSurname"]) . "</td><td>{$row["userEmail"]}</td><td>{$row["userMobileNumber"]}</td></tr><tr><td colspan=4><hr></td></tr>";
						}
					}
			}
	
	$html_out .= "</table>";
	
	mysqli_close($con);
	
	echo "[OUT]".$html_out."[OUT]";
}

if ($mode == "chkPass") {
		include "db.php";
	
		$psw = explode("[*-*]", $_POST["data"])[0];
		$psw = hex2bin($psw);
		$un = explode("[*-*]", $_POST["data"])[1];
		$un = hex2bin($un);
		$phash = hashPassword($psw);

		$uuid = "00";

		$stmt = $con->prepare("SELECT UUID FROM mytasksuserdetails WHERE userEmail = '$un' AND userPass = '$phash'");
		$stmt->execute();
		$stmt->bind_result($uuid);
		$stmt->fetch();
		$stmt->close();	

		$uid = 0;
		$stmt = $con->prepare("SELECT UID FROM mytasksusers WHERE UUID = '$uuid'");
		$stmt->execute();
		$stmt->bind_result($uid);
		$stmt->fetch();
		$stmt->close();	

		$auth1_key = "0";
		$auth2_key = "0";
		
		// Generate unique code 1
		
		echo "[uuid]".$uuid."[uuid]";

		$stmt = $con->prepare("UPDATE mytasksusers SET AUTH1 = UUID() WHERE UUID = '$uuid'");
		$stmt->execute();
		$stmt->close();	

		$stmt = $con->prepare("SELECT AUTH1 FROM mytasksusers WHERE UUID = '$uuid'");
		$stmt->execute();
		$stmt->bind_result($auth1_key);
		$stmt->fetch();
		$stmt->close();	

		$stmt = $con->prepare("UPDATE mytasksusers SET AUTH2 = UUID() WHERE UUID = '$uuid'");
		$stmt->execute();
		$stmt->close();	

		$stmt = $con->prepare("SELECT AUTH2 FROM mytasksusers WHERE UUID = '$uuid'");
		$stmt->execute();
		$stmt->bind_result($auth2_key);
		$stmt->fetch();
		$stmt->close();	

		if ($uid > 0) {
			setcookie("MPUID",$uid,
			[
				'expires' => 0,
				'path' => '/',
				'secure' => true,
				'httponly' => true,
				'samesite' => 'Strict'
			]);
			setcookie("MPAUTHI",$auth1_key,
				[
					'expires' => 0,
					'path' => '/',
					'secure' => true,
					'httponly' => true,
					'samesite' => 'Strict'
				]);
			setcookie("MPAUTHII",$auth2_key,
				[
					'expires' => 0,
					'path' => '/',
					'secure' => true,
					'httponly' => true,
					'samesite' => 'Strict'
				]);

			echo "[RES]1[RES]";
		} else {
			echo "[RES]0[RES]";
		}

		mysqli_close($con);
	
}

if ($mode == "regnew") {
	include "db.php";
		$chk1 = 0;
		$stmt = $con->prepare("SELECT count(UUID) FROM mytasksuserdetails WHERE userEmail = '{$_POST["username"]}'");
		$stmt->execute();
		$stmt->bind_result($chk1);
		$stmt->fetch();
		$stmt->close();	

		if ($chk1 > 0) {
			echo "[RES]0[RES][MSG]Email address already exists on the system[MSG]";
		} else {

		$psw2 = hex2bin($_POST["userpass"]);
		$phash = hashPassword($psw2);
	
		$stmt = $con->prepare("SELECT UUID()");
		$stmt->execute();
		$stmt->bind_result($new_key);
		$stmt->fetch();
		$stmt->close();	
		
		$dt = date("Y-m-d H:i:s");
		
		$stmt = $con->prepare("INSERT INTO mytasksuserdetails(userEmail,UUID,userPass,role,registeredWhen) VALUES('{$_POST["username"]}','{$new_key}','{$phash}','1','{$dt}')");
		$stmt->execute();
		$stmt->close();	

		$stmt = $con->prepare("INSERT INTO mytasksusers(UUID) VALUES ('{$new_key}')");
		$stmt->execute();
		$stmt->close();	
			
			echo "[RES]1[RES][MSG]All is good[MSG]";
			
		}

	mysqli_close($con);
}

if ($mode == "getUserDetail") {
	include "db.php";
	
	$stmt = $con->prepare("SELECT UUID FROM mytasksusers WHERE UID = '$uid'");
	$stmt->execute();
	$stmt->bind_result($_uuid);
	$stmt->fetch();
	$stmt->close();	

	$stmt = $con->prepare("SELECT userName,userSurname,userMobileNumber,userEmail,userImage,registeredWhen,role FROM mytasksuserdetails WHERE UUID = '$_uuid'");
	$stmt->execute();
	$stmt->bind_result($_userName,$_userSurname,$_userMobileNumber,$_userEmail,$_userImage,$_registeredWhen,$_role);
	$stmt->fetch();
	$stmt->close();	

	echo "[FN]". hex2bin($_userName) . "[FN]";
	echo "[LN]". hex2bin($_userSurname) . "[LN]";
	echo "[MN]{$_userMobileNumber}[MN]";
	echo "[EM]{$_userEmail}[EM]";
	echo "[IMG]{$_userImage}[IMG]";
	echo "[RW]{$_registeredWhen}[RW]";
	echo "[RL]{$_role}[RL]";
		
	mysqli_close($con);
}




?>