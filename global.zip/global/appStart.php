<?PHP
date_default_timezone_set('Africa/Johannesburg');
// root reference
$WEBSITE_DOMAIN = $_SERVER['REQUEST_SCHEME'] .'://'. $_SERVER['HTTP_HOST']."/global";
$PAGE_MODE = "START";
//JS constant via cookie

			setcookie("CNJS",$WEBSITE_DOMAIN,
			[
				'expires' => 0,
				'path' => '/',
				'secure' => true,
				'httponly' => true,
				'samesite' => 'Strict'
			]);

			setcookie("LS",1,
			[
				'expires' => 0,
				'path' => '/',
				'secure' => true,
				'httponly' => true,
				'samesite' => 'Strict'
			]);

			setcookie("PS",5,
			[
				'expires' => 0,
				'path' => '/',
				'secure' => true,
				'httponly' => true,
				'samesite' => 'Strict'
			]);

$languages_list = "";
$interests_html = "";

	$uid = 0;
	$auth1 = "";
	$auth2 = "";

// Check if user is present and logged in
if (isset($_COOKIE["MPUID"]) && isset($_COOKIE["MPAUTHI"]) && isset($_COOKIE["MPAUTHII"])) {
	
	$uid = $_COOKIE["MPUID"];
	$auth1 = $_COOKIE["MPAUTHI"];
	$auth2 = $_COOKIE["MPAUTHII"];
	
	if ($uid > 0) {
		include "db.php";

		$user_uuid = "0000";
		$stmt = $con->prepare("SELECT uuid FROM mytasksusers WHERE uid = '$uid' AND AUTH1 = '$auth1' AND AUTH2 = '$auth2'");
		$stmt->execute();
		$stmt->bind_result($user_uuid);
		$stmt->fetch();
		$stmt->close();		
			
		if ($user_uuid == "0000") { // 0000 = not found / not logged in / not Auth
			$PAGE_MODE = "SHOW_LOGIN";
		} else {
			$PAGE_MODE = "SHOW_MEM_AREA";
		}
		
		mysqli_close($con);
		
	} else {
		$PAGE_MODE = "SHOW_LOGIN";
	}
} else {
	$PAGE_MODE = "SHOW_LOGIN";
}


?>