<?PHP
// db connection details

//$DBHOST = "localhost";
//$DBUSER = "root";
//$DBPASS = "";
//$DBNAME = "myprofiledb";

$DBHOST = "cp22.domains.co.za";
$DBUSER = "davecitc_dbadmin";
$DBPASS = "Bestdress11";
$DBNAME = "davecitc_myprofile";


// db connection

$con=mysqli_connect($DBHOST , $DBUSER , $DBPASS , $DBNAME);

?>