-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Jul 09, 2024 at 02:24 PM
-- Server version: 10.6.18-MariaDB
-- PHP Version: 8.1.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- Table structure for table `mytasksuserdetails`
--

CREATE TABLE `mytasksuserdetails` (
  `idx` int(10) UNSIGNED NOT NULL,
  `UUID` varchar(36) DEFAULT NULL,
  `userName` varchar(200) DEFAULT NULL,
  `userSurname` varchar(200) DEFAULT NULL,
  `userMobileNumber` varchar(20) DEFAULT NULL,
  `userEmail` varchar(200) DEFAULT NULL,
  `userImage` varchar(200) DEFAULT NULL,
  `registeredWhen` datetime DEFAULT NULL,
  `role` tinyint(4) NOT NULL DEFAULT 0,
  `userPass` varchar(250) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;

-- --------------------------------------------------------

--
-- Table structure for table `mytasksusers`
--

CREATE TABLE `mytasksusers` (
  `UID` int(10) UNSIGNED NOT NULL,
  `UUID` varchar(36) DEFAULT NULL,
  `AUTH1` varchar(36) DEFAULT NULL,
  `AUTH2` varchar(36) DEFAULT NULL,
  `ACTIVE` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `user2FA` mediumint(8) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE `roles` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `roleId` tinyint(4) NOT NULL DEFAULT 0,
  `roleDescription` tinytext DEFAULT NULL,
  `shortName` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8mb3_bin;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `roleId`, `roleDescription`, `shortName`) VALUES
(1, 1, 'Standard User', 'STD'),
(2, 100, 'Full Administrative access', 'ADMIN');

-- --------------------------------------------------------

--
-- Table structure for table `taskDefinitions`
--

CREATE TABLE `taskDefinitions` (
  `ID` int(10) UNSIGNED NOT NULL,
  `taskTitle` varchar(500) DEFAULT NULL,
  `taskDescription` varchar(20000) DEFAULT NULL,
  `taskDueDate` datetime DEFAULT NULL,
  `taskAddDate` datetime DEFAULT NULL,
  `taskStatus` tinyint(3) UNSIGNED NOT NULL DEFAULT 1,
  `UUID` varchar(36) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `taskStatus`
--

CREATE TABLE `taskStatus` (
  `ID` tinyint(3) UNSIGNED NOT NULL,
  `statusDesc` varchar(20) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `taskStatus`
--

INSERT INTO `taskStatus` (`ID`, `statusDesc`) VALUES
(1, 'New'),
(2, 'Started'),
(3, 'in progress'),
(4, 'Final Stages'),
(5, 'Complete');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mytasksuserdetails`
--
ALTER TABLE `mytasksuserdetails`
  ADD PRIMARY KEY (`idx`),
  ADD UNIQUE KEY `EMAIL` (`userEmail`);

--
-- Indexes for table `mytasksusers`
--
ALTER TABLE `mytasksusers`
  ADD PRIMARY KEY (`UID`);

--
-- Indexes for table `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `taskDefinitions`
--
ALTER TABLE `taskDefinitions`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `taskStatus`
--
ALTER TABLE `taskStatus`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mytasksuserdetails`
--
ALTER TABLE `mytasksuserdetails`
  MODIFY `idx` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `mytasksusers`
--
ALTER TABLE `mytasksusers`
  MODIFY `UID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `roles`
--
ALTER TABLE `roles`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `taskDefinitions`
--
ALTER TABLE `taskDefinitions`
  MODIFY `ID` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `taskStatus`
--
ALTER TABLE `taskStatus`
  MODIFY `ID` tinyint(3) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;
